# Правила разработки TgStickerTool

## Архитектура

- **Feature-based структура**: Все функциональные модули в `src/renderer/src/features/`
- **Shared компоненты**: UI-компоненты в `src/renderer/src/shared/components/ui/`
- **Redux Toolkit**: Обязательное использование для state management
- **TypeScript**: Строгая типизация, никаких `any`

## Стилизация

- **Только SCSS Modules**: Файлы `[ComponentName].module.scss`
- **Переменные**: Использовать из `src/renderer/src/shared/styles/_variables.scss`
- **Radix UI**: Стилизация через data-атрибуты (`[data-state='open']`)
- **Запрещено**: Tailwind, Styled Components, inline styles (кроме исключений)

## Компоненты

- **UI примитивы**: Базируются на Radix UI
- **Доступность**: Обязательная поддержка скрин-ридеров
- **Типизация**: Все props должны иметь интерфейсы
- **Экспорт**: Через index.ts файлы

## Redux

- **Слайсы**: В директории фичи (`features/[feature]/[feature]Slice.ts`)
- **Хуки**: Использовать типизированные `useAppDispatch`, `useAppSelector`
- **Store**: Централизованный в `src/renderer/src/app/store.ts`

## Electron

- **IPC**: Типы в `src/common/types.ts`
- **Безопасность**: contextBridge в preload.ts
- **Main процесс**: Минимальная логика, только управление окнами

## Код

- **Минимализм**: Писать только необходимый код
- **Читаемость**: Код должен быть самодокументируемым
- **Комментарии**: Только для сложной логики
- **Импорты**: Абсолютные пути через алиасы (если настроены)

## Git

- **Коммиты**: Описательные сообщения на русском
- **Ветки**: feature/*, fix/*, refactor/*
- **Не коммитить**: node_modules/, dist/, release/, .env
